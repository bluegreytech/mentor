</body>
</html>
 <script src="<?php echo base_url(); ?>default_2/js/jquery.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->

<script src="<?php echo base_url(); ?>default_2/js/global-plugins.js"></script>
<script src="<?php echo base_url(); ?>default_2/js/theme.js" type="text/javascript" ></script>
<script src="<?php echo base_url(); ?>default_2/js/forms.js" type="text/javascript" ></script>
<script src="<?php echo base_url(); ?>default_2/js/chart.min.js" type="text/javascript" ></script>
<script src="<?php echo base_url(); ?>default_2/js/summernote.min.js" type="text/javascript" ></script>

<script src="<?php echo base_url(); ?>default_2/js/ecommerce.js" type="text/javascript" ></script>
<script src="<?php echo base_url(); ?>default_2/js/lightslider.js"></script>

<script src="<?php echo base_url(); ?>default_2/js/moment.js"></script>
<script src="<?php echo base_url(); ?>default_2/js/custom-new.js?1562847423"></script>
<script src="<?php echo base_url(); ?>default_2/js/alertify.min.js" type="text/javascript" ></script>
<script src="<?php echo base_url(); ?>default_2/js/enjoyhint.js"></script>
<script src="<?php echo base_url(); ?>default_2/js/jquery-touch.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>default/js/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

<script type="text/javascript">
   $(document).ready(function(){
   /*End of book session*/
        new WOW().init();
    
        App.initPage();
        App.initLeftSideBar();
        
    });
   
</script>



</body>
</html>