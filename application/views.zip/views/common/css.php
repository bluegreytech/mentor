<!DOCTYPE html>
<html>
<head>
<title>Mentor Together  | Leading  Career counselling platform</title>
    <!-- META TAGS -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keyword" content="">
    <!-- FAV ICON(BROWSER TAB ICON) -->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>default/images/favicon.png" type="image/x-icon"-->
    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    <!-- FONTAWESOME ICONS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>default/css/font-awesome.min.css">
    <!-- ALL CSS FILES -->
    <link href="<?php echo base_url(); ?>default/css/materialize.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>default/css/bootstrap.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>default/css/style.css" rel="stylesheet" />
    
    <!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
    <link href="<?php echo base_url(); ?>default/css/style-mob.css" rel="stylesheet" />
    <link href="<?php echo base_url(); ?>default/css/slider.css" rel="stylesheet" />
    <script src="<?php echo base_url(); ?>default/js/jssor.slider-27.5.0.min.js"></script>
    <script src="<?php echo base_url(); ?>default/js/slider.js"></script>   
   <!-- CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>default/css/alertify.min.css"/>
    <!-- Default theme -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>default/css/default.min.css"/>
    <!-- Semantic UI theme -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>default/css/semantic.min.css"/>
    <!--  alertify css and js  start  -->
    <!--  alertify css and js  start  -->
     <link rel="stylesheet" href="<?php echo base_url(); ?>default/css/alertify.rtl.min.css"/>
    <!-- Default theme -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>default/css/default.rtl.min.css"/>
    <!-- Semantic UI theme -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>default/css/semantic.rtl.min.css"/>

</head>