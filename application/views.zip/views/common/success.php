<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('common/header');
?>


 
   <!--SECTION START-->
    <section style="background:#f6f6f6;">
        <div class="container com-sp pad-bot-70">
            <div class="row">
                <div class="cor">
                    <div class="ed-about-tit">
                        <div class="con-title">
                            <h2>Success<span> Stories</span></h2>
                        </div>
                    </div>
                    <div class="pg-contact">
                        <!--First stories-->
                        <div class="row">
                          <div class="col-md-1"></div>
                          <div class="col-md-10">
                              <div class="col-md-7" style="padding: 0">
                                <div class="content-box" style="background-color: #fff">
                                <h5>How Overcame her Inhibitions and Biases to Choose the Stream Best Aligned to her Career Goals</h5>
                                <p>He was unsure about her streams and subjects for class 11th. Mentor career experts found her perfect fit with humanities, and helped her deal with her misconceptions about the field. She is now acing her class 11 and looks forward to a career in Psychology.</p>
                                
                                </div>
                              </div>
                              <div class="col-md-5" style="padding: 0">
                                <img src="<?php echo base_url(); ?>default/images/lg.png" class="img-responsive">
                              </div>
                          </div>
                          <div class="col-md-1"></div>
                        </div>
                        <br><br>
                         <div class="row">
                          <div class="col-md-1"></div>
                          <div class="col-md-10">
                              <div class="col-md-7" style="padding: 0">
                                <div class="content-box" style="background-color: #fff">
                                <h5>How Overcame her Inhibitions and Biases to Choose the Stream Best Aligned to her Career Goals</h5>
                                <p>He was unsure about her streams and subjects for class 11th. Mentor career experts found her perfect fit with humanities, and helped her deal with her misconceptions about the field. She is now acing her class 11 and looks forward to a career in Psychology.</p>
                                
                                </div>
                              </div>
                              <div class="col-md-5" style="padding: 0">
                                <img src="<?php echo base_url(); ?>default/images/lg.png" class="img-responsive">
                              </div>
                          </div>
                          <div class="col-md-1"></div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--SECTION END-->
</div>
<!-- <input type="hidden" id="csrf_mindler_token" name="ci_csrf_token" value=""> -->
<?php 
 $this->load->view('common/footer');
?>